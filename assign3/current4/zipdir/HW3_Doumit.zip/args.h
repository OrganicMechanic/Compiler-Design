/*
 * Joel Doumit
 * Code written by Andrew Schwartzmeyer for his 120++ compiler. 
 * args.h - Args available throughout program.
 *
 */

#ifndef ARGS_H
#define ARGS_H

#include <argp.h>
#include <stdbool.h>

struct arguments {
	bool debug;
	bool tree;
	bool symbols;
	bool checks;
	char **input_files;
} arguments;

#endif /* ARGS_H */
